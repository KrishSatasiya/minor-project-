# StoreIt - Modern Google Drive Clone

## 🚀 Overview
StoreIt is a high-performance, responsive file management system built with Next.js 15 and Appwrite. It provides a seamless experience for uploading, organizing, and sharing documents, images, and media files.

## 🛠️ Technical Stack
- **Framework**: Next.js 15 (App Router, Turbopack)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Backend**: Appwrite (BaaS)
- **UI Components**: Shadcn UI
- **Forms**: React Hook Form + Zod
- **Icons**: Lucide React

## ✨ Key Features
- **OTP Authentication**: Secure login and registration using email-based One-Time Passwords (OTP).
- **File Management**:
  - Drag-and-drop file uploading.
  - Multi-type file support (Documents, Images, Video, Audio).
  - Real-time search and filtering.
  - Sorting by name, date, and size.
- **Dynamic Dashboard**: Visual overview of storage usage across different file categories using Recharts.
- **Responsive Design**: Fully optimized for Desktop, Tablet, and Mobile views.
- **Collaborative Features**: Shareable file links and individual file management.

## 🔗 Third-Party Integrations
- **Appwrite**: Handles authentication, database management (metadata), and cloud storage (file buckets).
- **Recharts**: Powers the dashboard visualization for storage distribution.
- **Lucide React**: Provides a consistent and modern icon set.
- **Shadcn UI**: Provides accessible and customizable UI primitives like Modals, Sheets, and Forms.

## 🔒 Security Best Practices
- **Environment Variables**: All sensitive API keys and endpoints are stored in `.env` files.
- **Server-Side Actions**: Critical operations are handled via Next.js Server Actions for enhanced security.
- **Validation**: Strict schema validation using Zod for all form inputs and API interactions.
- **Git Hygiene**: Sanitized commit history and `.gitignore` configuration for public release.
